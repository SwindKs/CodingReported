package com.lzj.mapper;
import java.sql.SQLException;
import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.lzj.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.stereotype.Repository;

/**
* @author laizengjin
* @description 针对表【user】的数据库操作Mapper
* @createDate 2023-12-17 15:46:02
* @Entity com.lzj.entity.User
*/
@Mapper
public interface UserMapper extends BaseMapper<User> {
    @Override
    int insert(User user);

    User findUser(User user) throws SQLException;
    List<User> selectAll();

    int insertSelective(User user);
}




