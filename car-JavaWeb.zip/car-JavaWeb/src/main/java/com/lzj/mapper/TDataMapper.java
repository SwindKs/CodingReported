package com.lzj.mapper;

import com.lzj.entity.TData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.io.Serializable;
import java.util.List;

/**
* @author laizengjin
* @description 针对表【t_data】的数据库操作Mapper
* @createDate 2023-12-18 20:04:35
* @Entity com.lzj.entity.TData
*/
@Mapper
public interface TDataMapper extends BaseMapper<TData> {
    List<TData> findDataByPage (Integer page1, Integer limit1);

    int save(TData data);

    List<TData> selectDataByDesc();

    int deleteById(String c_id);

    void editData(String id, String temp, String humi, String light, String smoke, String co2, String tvoc);


    int selectCount();
}




