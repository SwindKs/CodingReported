package com.lzj.controller;

import com.lzj.entity.User;
import com.lzj.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.sql.SQLException;
import java.util.List;

@Controller
@CrossOrigin
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping("/login")
    public ModelAndView login(ModelAndView modelAndView){
        modelAndView.setViewName("login");
        return modelAndView;
    }
    @RequestMapping("/register")
    public ModelAndView register(ModelAndView modelAndView){
        modelAndView.setViewName("register");
        return modelAndView;
    }
    @RequestMapping("/index")
    public ModelAndView index(ModelAndView modelAndView){
        modelAndView.setViewName("index");
        return modelAndView;
    }

    @RequestMapping("/selectAllUser")
    public List<User> findAllUser(){
        return userService.selectAll();
    }
    @RequestMapping("/registerAction")
    public void registerAction( String username , String password){
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        userService.insertSelective(user);
    }
    @RequestMapping("/loginAction")
    public String loginAction(String username , String password, HttpSession session) throws SQLException {
        session.setAttribute("curStudent",null);
        session.setAttribute("curAdmin",null);
        User user = userService.findUser(new User(username,password));
        if(user!=null){
            session.setAttribute("curStudent",user);
            session.setAttribute("name",user.getUsername());
            session.setAttribute("s_id",user.getUid());
            return "redirect:/index";
        }
        return "login";
    }
    @RequestMapping("/regAction")
    public String regAction(String username , String password, HttpSession session) throws SQLException {
        session.setAttribute("curStudent",null);
        session.setAttribute("curAdmin",null);
        User user = new User(username,password);
        int i = userService.insertSelective(user);
        if(i>0){
            session.setAttribute("curStudent",user);
            session.setAttribute("name",user.getUsername());
            session.setAttribute("s_id",user.getUid());
            return "redirect:/register";
        }
        return "register";
    }
}
