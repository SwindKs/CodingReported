package com.lzj.controller;

import com.alibaba.fastjson2.JSON;
import com.lzj.entity.TData;
import com.lzj.service.TDataService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.SQLOutput;
import java.time.*;
import java.util.*;

@Controller
@CrossOrigin
public class DataController {
    @Autowired
    TDataService dataService;

    @RequestMapping("/data")
    public ModelAndView data(ModelAndView modelAndView){
        modelAndView.setViewName("data");
        return modelAndView;
    }
    @RequestMapping("/form_bar")
    public ModelAndView form_bar(ModelAndView modelAndView){
        modelAndView.setViewName("form_bar");
        return modelAndView;
    }
    @RequestMapping("/form_line")
    public ModelAndView form_line(ModelAndView modelAndView){
        modelAndView.setViewName("form_line");
        return modelAndView;
    }
    @RequestMapping("/editShow")
    public ModelAndView editShow(ModelAndView modelAndView){
        modelAndView.setViewName("editShow");
        return modelAndView;
    }
    @ResponseBody
    @RequestMapping("/listData")
    public List<TData> selectData(){
        return dataService.selectDataByDesc();
    }

    @RequestMapping(value = "/data/insert", method = RequestMethod.GET)
    @ResponseBody
    public String insert(TData data){
        // 1.当前日期
        LocalDateTime now1 = LocalDateTime.now();
// 2.当前日期 (指定时区)
        LocalDateTime now2 = LocalDateTime.now(ZoneId.of("Asia/Shanghai"));
// 3.当前日期 (指定时钟)
        LocalDateTime now3 = LocalDateTime.now(Clock.systemDefaultZone());
// 4.指定日期 2023-01-01 01:01:00
        LocalDateTime localDateTime1 = LocalDateTime.of(2023, 1, 1, 1, 1);
// 4.使用LocalDate和LocalTime对象创建LocalDateTime对象
        LocalDate localDate = LocalDate.now();
        LocalTime localTime = LocalTime.now();
        LocalDateTime localDateTime2 = LocalDateTime.of(localDate, localTime);
        data.setDatatime(localDateTime2+"");

        System.out.println(data.toString());

        return dataService.saveData(data);
    }

    //首页数据接口
    @RequestMapping(value = "/t_data",produces="text/html;charset=utf-8",method = RequestMethod.GET)
    @ResponseBody
    public String findAll(String page, String limit, HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        //分页查询,限制每页三条
        Integer limit1 = Integer.parseInt(limit);
        Integer page1 = (Integer.parseInt(page)-1)*limit1;
        List<TData> list1 = dataService.findDataByPage(page1,limit1);
        //System.out.println(list1.toString());
        Map<String,Object> mapData = new HashMap<>();
        mapData.put("code",0);
        mapData.put("msg","");
        mapData.put("count",dataService.selectCount());
        mapData.put("data",list1);
        return  JSON.toJSONString(mapData);
    }
//    @RequestMapping(value = "/data_bar")
//    @ResponseBody
//    public Map<String, Object> data_bar(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
//        TData tData = dataService.selectDataByDesc();
//        //System.out.println(list1.toString());
//        List<String> data_bar = new ArrayList<String>();
//        data_bar.add(tData.getTemp());
//        data_bar.add(tData.getHumi());
//        data_bar.add(tData.getLight());
//        data_bar.add(tData.getCo2());
//        data_bar.add(tData.getTvoc());
//
//        Map<String,Object> mapData = new LinkedHashMap<String, Object>();
//        mapData.put("code",0);
//        mapData.put("msg","");
//        mapData.put("count",10);
//        mapData.put("data",data_bar);
//        System.out.println(data_bar.toString());
//        return  (mapData);
//    }
    @RequestMapping(value = "/data_bar")
    @ResponseBody
    public Map<String, Object> data_bar_temp(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        List<TData> tData = dataService.selectDataByDesc();
        //System.out.println(list1.toString());
        List<String> data_bar = new ArrayList<String>();
        List<String> data_humi = new ArrayList<String>();
        List<String> data_shidu = new ArrayList<String>();
        List<String> data_light = new ArrayList<String>();
        List<String> data_co2 = new ArrayList<String>();
        List<String> data_tvoc = new ArrayList<String>();
        List<String> data_time = new ArrayList<String>();

        data_humi.add(tData.get(0).getHumi());
        data_humi.add(tData.get(1).getHumi());
        data_humi.add(tData.get(2).getHumi());
        data_humi.add(tData.get(3).getHumi());
        data_humi.add(tData.get(4).getHumi());

        data_light.add(tData.get(0).getLight());
        data_light.add(tData.get(1).getLight());
        data_light.add(tData.get(2).getLight());
        data_light.add(tData.get(3).getLight());
        data_light.add(tData.get(4).getLight());

        data_shidu.add(tData.get(0).getSmoke());
        data_shidu.add(tData.get(1).getSmoke());
        data_shidu.add(tData.get(2).getSmoke());
        data_shidu.add(tData.get(3).getSmoke());
        data_shidu.add(tData.get(4).getSmoke());

        data_co2.add(tData.get(0).getCo2());
        data_co2.add(tData.get(1).getCo2());
        data_co2.add(tData.get(2).getCo2());
        data_co2.add(tData.get(3).getCo2());
        data_co2.add(tData.get(4).getCo2());

        data_tvoc.add(tData.get(0).getTvoc());
        data_tvoc.add(tData.get(1).getTvoc());
        data_tvoc.add(tData.get(2).getTvoc());
        data_tvoc.add(tData.get(3).getTvoc());
        data_tvoc.add(tData.get(4).getTvoc());


        data_time.add(tData.get(0).getDatatime());
        data_time.add(tData.get(1).getDatatime());
        data_time.add(tData.get(2).getDatatime());
        data_time.add(tData.get(3).getDatatime());
        data_time.add(tData.get(4).getDatatime());

        data_bar.add(tData.get(0).getTemp());
        data_bar.add(tData.get(1).getTemp());
        data_bar.add(tData.get(2).getTemp());
        data_bar.add(tData.get(3).getTemp());
        data_bar.add(tData.get(4).getTemp());

        Map<String,Object> mapData = new LinkedHashMap<String, Object>();
        mapData.put("code",0);
        mapData.put("msg","");
        mapData.put("count",10);
        mapData.put("data",data_bar);
        mapData.put("data_humi",data_humi);
        mapData.put("data_shidu",data_shidu);
        mapData.put("data_light",data_light);
        mapData.put("data_co2",data_co2);
        mapData.put("data_tvoc",data_tvoc);
        mapData.put("data_time",data_time);
        System.out.println(data_bar.toString());
        System.out.println(data_time.toString());
        return  (mapData);
    }
    @RequestMapping("/delData")
    public String delData(String c_id){
        dataService.deleteById(c_id);
        return  "redirect:/data";
    }
    @RequestMapping("/editData")
    public String editData(String id,String temp,String humi,String light,String shidu,String co2,String tvoc){
        dataService.editData(id,temp,humi,light,shidu,co2,tvoc);
        return  "redirect:/data";
    }
}
