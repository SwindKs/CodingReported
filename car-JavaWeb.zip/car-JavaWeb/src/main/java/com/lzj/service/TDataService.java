package com.lzj.service;

import com.lzj.entity.TData;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
* @author laizengjin
* @description 针对表【t_data】的数据库操作Service
* @createDate 2023-12-18 20:04:35
*/
public interface TDataService extends IService<TData> {
    List<TData> findDataByPage (Integer page1, Integer limit1);

    String saveData(TData data);

    List<TData> selectDataByDesc();

    int deleteById(String c_id);

    void editData(String id, String temp, String humi, String light, String smoke, String co2, String tvoc);

    int selectCount();

}
