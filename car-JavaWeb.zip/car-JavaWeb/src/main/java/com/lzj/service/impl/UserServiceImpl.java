package com.lzj.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lzj.entity.User;
import com.lzj.service.UserService;
import com.lzj.mapper.UserMapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

/**
* @author laizengjin
* @description 针对表【user】的数据库操作Service实现
* @createDate 2023-12-17 15:46:02
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
    implements UserService{
    @Autowired
    private UserMapper userMapper;


    @Override
    public int insert(User user) {
        return userMapper.insert(user);
    }

    @Override
    public List<User> selectAll() {
        return userMapper.selectAll();
    }

    @Override
    public int insertSelective(User user) {
        return userMapper.insertSelective(user);
    }

    public User findUser(User user) throws SQLException {
        return userMapper.findUser(user);
    }

}




