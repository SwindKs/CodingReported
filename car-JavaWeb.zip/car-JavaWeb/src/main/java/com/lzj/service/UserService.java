package com.lzj.service;

import com.lzj.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

import java.sql.SQLException;
import java.util.List;

/**
* @author laizengjin
* @description 针对表【user】的数据库操作Service
* @createDate 2023-12-17 15:46:02
*/
public interface UserService extends IService<User> {
    int insert(User user);
    User findUser(User user) throws SQLException;
    List<User> selectAll();

    int insertSelective(User user);
}
