package com.lzj.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lzj.entity.TData;
import com.lzj.service.TDataService;
import com.lzj.mapper.TDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

/**
* @author laizengjin
* @description 针对表【t_data】的数据库操作Service实现
* @createDate 2023-12-18 20:04:35
*/
@Service
public class TDataServiceImpl extends ServiceImpl<TDataMapper, TData>
    implements TDataService{
    @Autowired
    TDataMapper mapper;

    @Override
    public List<TData> findDataByPage(Integer page1, Integer limit1) {
            return mapper.findDataByPage(page1,limit1);
        }

    @Override
    public String saveData(TData data) {
        mapper.save(data);
        return "OK";
    }

    @Override
    public List<TData> selectDataByDesc() {
        return mapper.selectDataByDesc();
    }

    @Override
    public int deleteById(String c_id) {
        return mapper.deleteById(c_id);
    }

    @Override
    public void editData(String id, String temp, String humi, String light, String smoke, String co2, String tvoc) {
        mapper.editData( id,  temp,  humi,  light,  smoke,  co2,  tvoc) ;
    }

    @Override
    public int selectCount() {
        return mapper.selectCount();
    }




}




