package com.lzj.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @TableName t_data
 */
@TableName(value ="t_data")
@Data
@Getter
@Setter
public class TData implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 空气温度
     */
    private String temp;

    /**
     * 空气湿度
     */
    private String humi;

    /**
     * 光照强度
     */
    private String light;

    /**
     * Smoke
     */
    private String smoke;

    /**
     * 二氧化碳
     */
    private String co2;

    /**
     * 空气质量
     */
    private String tvoc;

    private String datatime;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}